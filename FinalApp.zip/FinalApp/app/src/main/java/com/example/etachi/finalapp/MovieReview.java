package com.example.etachi.finalapp;

public class MovieReview {

    String author;
    String content;

    public MovieReview(String author, String content){
        this.author=author;
        this.content=content;
    }
}
