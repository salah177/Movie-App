package com.example.etachi.finalapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
   // private static final String TAG = MainActivity.class.getSimpleName();
    SharedPreferences sharedpreferences;
    public static boolean tablet =false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (findViewById(R.id.tablet_frame) != null) {
            if (savedInstanceState != null) {
                return;
            }
            this.tablet = true;
            MainActivityFragment MovieFragment = new MainActivityFragment();
            MovieFragment.setArguments(getIntent().getExtras());
        }



        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        assert getSupportActionBar() != null;
        getSupportActionBar().setLogo(R.mipmap.pop_movies);

        sharedpreferences = getSharedPreferences("app_prefs", MODE_PRIVATE);
    }
}
