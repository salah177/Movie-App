package com.example.etachi.finalapp;

public class MovieTrailer {
    String videoName;
    String videoKey;

    public  MovieTrailer(String videoKey,String videoName){
        this.videoName=videoName;
        this.videoKey=videoKey;
    }

}
